
#include "dataGenerator.h"
const string bigStr="qwertyuioplkjhgfdsazxcvbnmzxcvbnmasdfghjklqwertyuiopzxcvbnmasdfghjklqwertyuiopqwertyuiopasdfghjklzxcvbnm";
dataGenerator::dataGenerator(vector<column> vcolMetadata,long records) 
{
	m_vcolMetadata = vcolMetadata;
	m_records = records;
	m_colDelimiter="|";
	m_recDelimeter="\n";
	m_vrecords.reserve(m_records);
}

void dataGenerator::setColDelimeter(string delimeter)
{
	m_colDelimiter=delimeter;
}
void dataGenerator::setRecDelimiter(string delimiter)
{
	m_recDelimeter=delimiter;
}
void dataGenerator::generateRec()
{
	genData();

	long index=0;
	while(index < m_vcolMetadata.size())
	{
		column col = m_vcolMetadata[index];
		vector<string> v_coldata=m_mcolData[col.name];
		for(long i=0; i<m_records; i++)
		{
			if(0==index)
			{			
				m_vrecords.push_back(v_coldata[i]);				
			}
			else
			{
				m_vrecords[i].append(v_coldata[i].c_str());
			}
			m_vrecords[i].append(m_colDelimiter);
		}
		index++;
	}
	for(long i=0; i<m_records; i++)
	{
		int start = m_vrecords[i].rfind(m_colDelimiter);
		m_vrecords[i].replace(start, m_colDelimiter.size(),m_recDelimeter);	
		cout<<m_vrecords[i].c_str();
	}
}

void dataGenerator::genData()
{
	long index=0;
	
	while(index < m_vcolMetadata.size())
	{
		column col = m_vcolMetadata[index];
		cout<<"Generating record for column "<<col.name.c_str()<<endl;
		if(!col.input.compare("format"))
		{
			string format = col.format;
			if(string::npos != format.find("random_str"))
			{
				int min,max;
				int begin = format.find("(",format.find("random_str"));				
				int end = format.find(",",begin);
				if(string::npos==end)
					end = format.find(")",begin);					
				string str = format.substr(begin+1, end-(begin+1));
				min = atoi(str.c_str());
				
				begin = end;
				end = format.find(")",begin);
				str = format.substr(begin+1, end-(begin+1));
				max = atoi(str.c_str());
				m_mcolData.insert (make_pair(col.name, random_str(min, max)));
			}
			if(string::npos != format.find("incremental"))
			{
				long init=1;
				long diff=1;
				int begin = format.rfind("(");
				int end = format.rfind(",");
				string str = format.substr(begin+1, end-(begin+1));
				init = atol(str.c_str());
				
				
				begin = end;
				end = format.rfind(")");
				str = format.substr(begin+1, end-(begin+1));
				diff = atol(str.c_str());
				m_mcolData.insert (make_pair(col.name, increment(init, diff)));
			}
		}
		index++;
	}

}
vector<string> dataGenerator::random_str(int min, int max=0)
{
	cout << max <<min<<endl;
	
	vector <string> v_colvalue;
	v_colvalue.reserve(m_records);
	unsigned long count=0;
	srand(bigStr.size());
	
	while(count < m_records)
	{
		int len=0;
		if(max > min)
			len = (rand()%(max-min))+min;	
		else
			len=min;
		int index = rand()%(bigStr.size()-len);	
		v_colvalue.push_back(bigStr.substr(index,len));
		count++;
	}
	return v_colvalue;
}

vector<string> dataGenerator::increment(long begin, long diff)
{
	unsigned long count=0;
	char str[15];
	vector<string> v_colvalue;

	while(count < m_records)
	{
		sprintf(str,"%ld", begin);
		v_colvalue.push_back(str);
		begin += diff;
		count++;
	}
	return v_colvalue;
}