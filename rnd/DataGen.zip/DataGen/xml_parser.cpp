#include "xml_parser.h"

xmlParser::xmlParser(string file):m_xmlFile(file)
{
	m_hxml.open(m_xmlFile.c_str());
	if(!m_hxml)
	{
		cout<<"Error: Failed to open file "<<m_xmlFile.c_str()<<endl;
	}
}
unsigned int xmlParser::getsize()
{
	//unsigned int start=m_hxml.tellg();
	long start=0;
	long end=0;
	long curr=0;
	
	curr = m_hxml.tellg();
	m_hxml.seekg(0L);
	start = m_hxml.tellg();

	m_hxml.seekg(0L, ios::end);
	end=m_hxml.tellg();
	
	m_hxml.seekg(curr);
	long size = end - start;
	return size;
}
int xmlParser::readfile()
{
	long size = 500;//getsize();
	char* buffer;
	buffer = new char[size+1];
	//m_hxml.getline(buffer,size);
	m_hxml.read(buffer, size);
	
	buffer[size]=0;
	m_strxml.assign(buffer);
	int si = m_strxml.find ("<table");
	int ei = m_strxml.find("</table>");
	string substr=m_strxml.substr(si,ei-si+8);
	delete [] buffer;
	//cout<<m_strxml.c_str()<<endl;
	cout<<substr.c_str()<<endl;
	m_strxml=substr;
	tokenize();
	parseTokens();
	return true;	
}
void xmlParser::tokenize()
{
	long size=m_strxml.size();
	long index=0;
	bool openQuote=0;
	
	bool openComment=0;
	string token;
	while(index<size)
	{
		//ignore comments
		if(!m_strxml.substr(index,4).compare("<!--") && !openComment)
		{	
			if(token.size())
			{
				m_xmltokens.push_back(token);
				token="";
			}
			index +=4;
			openComment=1;
			continue;
		}
		else if(openComment)
		{
			if(!m_strxml.substr(index,3).compare("-->"))
			{
				index +=3;
				openComment=0;
				continue;
			}			
		}
		//capture values in double quotes
		else if(!m_strxml.substr(index,1).compare("\"") && !openQuote)
		{
			if(token.size())
			{
				m_xmltokens.push_back(token);
				token="";
			}
			openQuote=1;
		}
		else if(openQuote)
		{
			if(!m_strxml.substr(index,1).compare("\""))
			{

				m_xmltokens.push_back(token);
				token="";
				openQuote=0;
			}
			else
			{			
				token.append(m_strxml.substr(index,1));
			}
			//continue;
		}
		else if(m_strxml[index]=='=' )
		{			
			if(token.size())
			{
				m_xmltokens.push_back(token);
				token="";
			}			
			//m_xmltokens.push_back(m_strxml.substr(index,1));
		}
		else if(m_strxml[index]==10 )
		{
			if(token.size())
			{
				m_xmltokens.push_back(token);
				token="";
			}
			if(m_strxml[index+1]==9)
				index++;//
			

			//continue;
		}
		else if(m_strxml[index]==' ' )
		{			
			if(token.size())
			{
				m_xmltokens.push_back(token);
				token="";
			}			
		}	
		else if(!m_strxml.substr(index,2).compare("</") || !m_strxml.substr(index,2).compare("/>"))
		{
			if(token.size())
			{
				m_xmltokens.push_back(token);
				token="";
			}
			m_xmltokens.push_back(m_strxml.substr(index,2));
			index +=2;
			continue;
		}
		else if(m_strxml[index]=='<' || m_strxml[index]=='>')
		{
			if(token.size())
			{
				m_xmltokens.push_back(token);
				token="";
			}
			m_xmltokens.push_back(m_strxml.substr(index,1));			
		}
		else
		{
			token.append(m_strxml.substr(index,1));		
		}
		index++;
	}
	token="";
	for(index=0; index<m_xmltokens.size();index++)
		cout<<m_xmltokens[index]<<endl;
}

void xmlParser::parseTokens()
{
	long size = m_xmltokens.size();
	long index=0;
	bool openColTag=0;
	column col;
	while(index<size)
	{
		if(!m_xmltokens[index].compare("<") && !m_xmltokens[index+1].compare("column"))
		{
			openColTag=1;
			index++;
		}
		else if(!m_xmltokens[index].compare("/>"))
		{
			validateColumn(col);				
			v_colMetadata.push_back(col);
			openColTag=0;
		}
		else if(openColTag)
		{
			string key = m_xmltokens[index];
			string value = m_xmltokens[index+1];
			if(!key.compare("name"))
			{
				col.name=value;
			}
			else if(!key.compare("input"))
			{
				col.input=value;
			}
			else if(!key.compare("format"))
			{
				col.format=value;
			}
			else if(!key.compare("output"))
			{
				col.output=atoi(value.c_str());
			}
			else if(!key.compare("unique"))
			{
				col.unique=atoi(value.c_str());
			}
			else
			{
				cout<<"ERROR: Unhandled column attributes '"<<key.c_str()<<"' = "<<value.c_str()<<endl;
			}
			index ++;
		}
		index++;
	}
}

bool xmlParser::validateColumn(column &col)
{
	//todo
	//exit ....ifnotvalid
	return 0;
}
vector<column> xmlParser::getColumnMetadataList()
{
	return v_colMetadata;
}