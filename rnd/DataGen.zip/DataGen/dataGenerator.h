#include<string>
#include<vector>
#include<map>
#include "definitions.h"

using namespace std;

class dataGenerator
{
	long m_records;
	vector<column> m_vcolMetadata;
	map<string,vector<string>> m_mcolData;
	vector<string> m_vrecords;
	string m_colDelimiter;
	string m_recDelimeter;
	void genData();
	vector<string> random_str(int min, int max);
	vector<string> increment(long begin, long diff=1);
	
public:
	dataGenerator(vector<column>,long);
	
	void setColDelimeter(string);
	void setRecDelimiter(string);
	void generateRec();
};