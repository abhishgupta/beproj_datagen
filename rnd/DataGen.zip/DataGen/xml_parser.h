#ifndef DATAGEN_XML_PARSER
#define DATAGEN_XML_PARSER

#include "definitions.h"

class xmlParser
{
	string m_xmlFile;
	ifstream m_hxml;
	string m_strxml;
	unsigned int getsize();
	vector<column> v_colMetadata;
	vector<string> m_xmltokens;
	void tokenize();
	void parseTokens();
	bool validateColumn(column&);
public:
	int readfile();
    xmlParser(string xml);
	string getTableName();
	//vector<string> getColumnList();
	vector<column> getColumnMetadataList();
};
#endif