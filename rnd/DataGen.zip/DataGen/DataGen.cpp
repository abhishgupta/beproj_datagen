
#include "xml_parser.h"
#include "dataGenerator.h"

using namespace std;

int main()
{

	xmlParser parser("C:\\Users\\nand\\Documents\\Visual Studio 2005\\Projects\\DataGen\\student.xml");
	int status = parser.readfile();
	vector<column> v_colMetadata = parser.getColumnMetadataList();

	dataGenerator dataGen(v_colMetadata, 100);
	dataGen.generateRec();

	return true;
}