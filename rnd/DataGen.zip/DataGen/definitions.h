#ifndef DATAGEN_DEFINITIONS
#define DATAGEN_DEFINITIONS
#include<string>
#include<vector>
#include<map>
#include<fstream>
#include<iostream>

using namespace std;

//Supported datatypes

////const short DGT_INTEGER=1;
////const short DGT_VARCHAR=2;
//
//
////Supported inputs
//const short DGI_FORMAT=1;
//const short DGI_FILE=2;

struct column
{
	string name;	//name of column
	string type;	//data type of column [optional]
	string input;	//input type to generate the data for the column, ex: format,file,foreignkey 
	string format;	//expresion to generate the data
	bool output;	//do we need to dump the data in output file, default will be true
	bool unique;		//value should be unique, default will be false

	column()
	{
		name="";
		type="";
		input="";
		format="";
		output=1;
		unique=0;
	}
};



#endif